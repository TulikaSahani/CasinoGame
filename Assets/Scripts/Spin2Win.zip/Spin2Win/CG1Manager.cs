﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;
using static BetManager;

public class CG1Manager : MonoBehaviour
{
    public static CG1Manager Instance;
    [Header("User Info")]
    public TMP_Text usernameText;
    [Header("Win Effects")]
    public GameObject glowEffect;

    [Header("Cross Panel")]
    public GameObject crossPanel;

    [Header("UI References")]
    public TMP_Text totalBetText;
    public TMP_Text statusText;

    [Header("Wheel Animation")]
    public WheelSpinner wheelSpinner;

    [Header("Chip Prefabs")]
    public GameObject chip5Prefab;
    public GameObject chip10Prefab;
    public GameObject chip50Prefab;
    public GameObject chip100Prefab;
    public GameObject chip500Prefab;

    [Header("API Settings")]
    public string baseUrl = "https://casino-backend.realtimevillage.com/api";
    public int gameId = 1;
    public float fallbackTime = 30f;
    public Image timerFillImage;

    [Header("Round End UI")]
    public GameObject endRoundPanel;
    public Button restartButton;
    public Button exitButton;

    [Header("Timer UI")]
    public TMP_Text timerText;
    public float warningThreshold = 15f;
    public float closingThreshold = 10f;

    private float gameTime = 0f;
    private bool bettingOpen = false;
    private int currentGameResultId = 0;

    [Header("Wallet Balance")]
    public TMP_Text walletBalanceText;
    public TMP_Text winningNumberText;
    public TMP_Text winningAmountText;

    private int currentWalletBalance = 0;
    private int totalWinnings = 0;
    private int winningNum = -1;

    [Header("Cards (0–9)")]
    public List<Spin2WinCard> cards = new List<Spin2WinCard>();

    [Header("Chips")]
    public List<Spin2WinChip> chipButtons = new List<Spin2WinChip>();

    private int selectedChipValue = 0;
    private GameObject selectedChipButton;

    private Dictionary<int, int> bets = new Dictionary<int, int>();
    private Dictionary<int, int> previousBets = new Dictionary<int, int>();
    [System.Serializable]
    public class Spin2WinBetRequest
    {
        public int game_result_id;
        public int game_id;
        public int play_point;

        public int zero, one, two, three, four, five, six, seven, eight, nine;
    }
    private void LoadUsername()
    {
        // Get username from PlayerPrefs (saved by UserManager)
        string username = PlayerPrefs.GetString("Username", "Guest");

        if (usernameText != null)
            usernameText.text = " " + username.ToUpper();

        Debug.Log($"Loaded username: {username}");
    }
    void Awake()
    {
        Instance = this;
    }
    public void SelectChip(int value, GameObject chipButton)
    {
        foreach (var chip in chipButtons)
        {
            chip.transform.localScale = Vector3.one; // Normal size
        }
        selectedChipValue = value;
        selectedChipButton = chipButton;
        chipButton.transform.localScale = Vector3.one * 1.2f; // 20% bigger
        if (statusText != null)
            statusText.text = "Selected chip: " + value;
    }
    public void ShowCrossPanel()
    {
        if (crossPanel != null)
            crossPanel.SetActive(true);
    }

    public void HideCrossPanel()
    {
        if (crossPanel != null)
            crossPanel.SetActive(false);
    }

    public void OnCrossYesClicked()
    {
        UnityEngine.SceneManagement.SceneManager.LoadScene(1); // Load main menu
    }

    public void OnCrossNoClicked()
    {
        HideCrossPanel();
    }
    // Repeat previous bets
    public void RepeatBets()
    {
        // Check if there are any previous bets to repeat
        if (previousBets.Count == 0)
        {
            if (statusText != null)
                statusText.text = "No previous bets to repeat!";
            return;
        }

        // Calculate total cost of repeating all previous bets
        int totalCost = 0;
        foreach (var bet in previousBets.Values)
        {
            totalCost += bet;
        }

        // Check if player has sufficient balance
        if (totalCost > currentWalletBalance)
        {
            if (statusText != null)
                statusText.text = $"Need ${totalCost} to repeat previous bets!";
            return;
        }

        // Clear current bets first
        ClearAllBets();

        // Place all previous bets
        foreach (var kvp in previousBets)
        {
            var card = cards.Find(c => c.cardNumber == kvp.Key);
            if (card != null && kvp.Value > 0)
            {
                // Add to current bets
                bets[kvp.Key] = kvp.Value;

                // Deduct from wallet
                currentWalletBalance -= kvp.Value;

                // Create visual chips
                if (card.chipContainer != null)
                {
                    GameObject prefab = GetChipPrefab(GetChipValueForAmount(kvp.Value));
                    if (prefab != null)
                    {
                        Instantiate(prefab, card.chipContainer);
                    }
                }
            }
        }

        UpdateTotalUI();
        UpdateWalletDisplay();

        if (statusText != null)
            statusText.text = "Previous bets repeated!";
    }

    // Called by number buttons (Spin2WinCard)
    public void PlaceChipOnCard(int cardNumber, GameObject cardObj)
    {
        Debug.Log($"Trying to place ${selectedChipValue} on {cardNumber}");
        Debug.Log($"Current balance: ${currentWalletBalance}");
        Debug.Log($"Total bets placed: ${GetTotalBetAmount()}");

        if (selectedChipValue <= 0)
        {
            if (statusText != null) statusText.text = "Select a chip first!";
            return;
        }
        int totalCurrentBet = GetTotalBetAmount();
        if (totalCurrentBet + selectedChipValue > currentWalletBalance)
        {
            if (statusText != null) statusText.text = "Insufficient balance!";
            return;
        }

        if (!bets.ContainsKey(cardNumber))
            bets[cardNumber] = 0;
        // DEDUCT FROM WALLET
       // currentWalletBalance -= selectedChipValue;
       // bets[cardNumber] += selectedChipValue;


        bets[cardNumber] += selectedChipValue;
        UpdateTotalUI();
       // UpdateWalletDisplay();

        Spin2WinCard card = cardObj.GetComponent<Spin2WinCard>();
        if (card != null && card.chipContainer != null)
        {
            GameObject prefab = GetChipPrefab(selectedChipValue);
            if (prefab != null)
            {
                Instantiate(prefab, card.chipContainer);
            }
        }

        if (statusText != null)
            statusText.text = $"Placed {selectedChipValue} on {cardNumber}";
    }
    private int GetTotalBetAmount()
    {
        int total = 0;
        foreach (var kvp in bets)
        {
            total += kvp.Value;
        }
        return total;
    }
    private GameObject GetChipPrefab(int value)
    {
        switch (value)
        {
            case 5: return chip5Prefab;
            case 10: return chip10Prefab;
            case 50: return chip50Prefab;
            case 100: return chip100Prefab;
            case 500: return chip500Prefab;
        }
        return null;
    }

    // Odds button
    public void ApplyChipToOdds()
    {
        if (selectedChipValue <= 0)
        {
            if (statusText != null) statusText.text = "Select a chip first!";
            return;
        }
        int oddNumbersCount = 0;
        foreach (var card in cards)
        {
            if (card.cardNumber % 2 == 1) // odd
                oddNumbersCount++;
           // PlaceChipOnCard(card.cardNumber, card.gameObject);
        }
        int totalCost = selectedChipValue * oddNumbersCount;
        if (totalCost > currentWalletBalance) {
            if (statusText != null) statusText.text = $"Need {totalCost} for all odds!";
            return;
        }
        foreach (var card in cards)
        {
            if (card.cardNumber % 2 == 1) // odd
                PlaceChipOnCard(card.cardNumber, card.gameObject);
        }
    }

    // Evens button
    public void ApplyChipToEvens()
    {
        if (selectedChipValue <= 0)
        {
            if (statusText != null) statusText.text = "Select a chip first!";
            return;
        }
        int evenNumbersCount = 0;
        foreach (var card in cards)
        {
            if (card.cardNumber % 2 == 0) // even
                evenNumbersCount++;
        }

        int totalCost = selectedChipValue * evenNumbersCount;
        if (totalCost > currentWalletBalance)
        {
            if (statusText != null) statusText.text = $"Need ${totalCost} for all evens!";
            return;
        }

        foreach (var card in cards)
        {
            if (card.cardNumber % 2 == 0) // even
                PlaceChipOnCard(card.cardNumber, card.gameObject);
        }
    }

    private void UpdateTotalUI()
    {
        int total = 0;
        foreach (var kvp in bets) total += kvp.Value;

        if (totalBetText != null)
            totalBetText.text = " " + total;
    }

    // For API integration later
    public Dictionary<int, int> GetBets()
    {
        return bets;
    }

    // Clear all bets
    public void ClearBets()
    {
        bets.Clear();
        UpdateTotalUI();
        foreach (var card in cards)
        {
            if (card != null && card.chipContainer != null)
            {
                // Destroy all chip children
                foreach (Transform child in card.chipContainer)
                {
                    Destroy(child.gameObject);
                }
            }
        }

        Debug.Log("All bets and chips cleared");
    
}
    void Start()
    {
        if (restartButton != null)
            restartButton.onClick.AddListener(() =>
            {
                endRoundPanel.SetActive(false);
                ClearBets();
                StartCoroutine(SetupRound()); // start new round
            });

        if (exitButton != null)
            exitButton.onClick.AddListener(() =>
            {
                UnityEngine.SceneManagement.SceneManager.LoadScene(1);
            });

        StartCoroutine(SetupRound());
    }

    IEnumerator SetupRound()
    {
        bettingOpen = false;
        ClearBets(); // reset bets/chips on UI
        ClearWinningsDisplay();

        if (timerFillImage != null)
        {
            timerFillImage.fillAmount = 1f;
           // timerFillImage.color = Color.green;
        }

        if (glowEffect != null)
            glowEffect.SetActive(false);

        LoadUsername();

        yield return StartCoroutine(FetchWalletBalance());

        string token = PlayerPrefs.GetString("AUTH_KEY", "");
        if (string.IsNullOrEmpty(token))
        {
            Debug.LogError("No AUTH_KEY found. Login first.");
            yield break;
        }

        // 1. Fetch latest-game-result-id
        string urlId = $"{baseUrl}/v1/result/latest-game-result-id?token={token}&game_id={gameId}";
        UnityWebRequest reqId = UnityWebRequest.Get(urlId);
        yield return reqId.SendWebRequest();

        if (reqId.result == UnityWebRequest.Result.Success)
        {
            var idWrap = JsonUtility.FromJson<LatestGameIdWrapper>(reqId.downloadHandler.text);
            if (idWrap != null && idWrap.data != null)
                currentGameResultId = idWrap.data.id;
        }

        // 2. Fetch latest-game-time
        string urlTime = $"{baseUrl}/v1/result/latest-game-time?token={token}&game_id={gameId}&game_result_id={currentGameResultId}";
        UnityWebRequest reqTime = UnityWebRequest.Get(urlTime);
        yield return reqTime.SendWebRequest();

        Debug.Log("Game Time API Response: " + reqTime.downloadHandler.text);

        
        gameTime = fallbackTime; // default
        if (reqTime.result == UnityWebRequest.Result.Success)
        {
            var tw = JsonUtility.FromJson<GameTimeWrapper>(reqTime.downloadHandler.text);
            if (tw != null && tw.data != null && tw.data.game_time > 0)
                gameTime = tw.data.game_time;
        }

        bettingOpen = true;
    }
    private void ClearWinningsDisplay()
    {
        if (winningNumberText != null)
            winningNumberText.text = " ";

        if (winningAmountText != null)
        {
            winningAmountText.text = "";
            winningAmountText.color = Color.white;
        }

        totalWinnings = 0;
        winningNum = -1;
    }
    void Update()
    {
       // if (Input.GetKeyDown(KeyCode.Escape)) // Or any other trigger
        //{
          //  ShowCrossPanel();
        //}
        if (bettingOpen && gameTime > 0)
        {
            gameTime -= Time.deltaTime;
            gameTime = Mathf.Max(0, gameTime);

            int sec = Mathf.FloorToInt(gameTime % 60);
            int min = Mathf.FloorToInt(gameTime / 60);
            timerText.text = $"{min:00}:{sec:00}";
            if (timerFillImage != null)
            {
                float fillAmount = gameTime / fallbackTime; // Use fallbackTime
                timerFillImage.fillAmount = fillAmount;

                if (gameTime <= closingThreshold)
                {
                    float pulse = Mathf.PingPong(Time.time * 3f, 0.4f) + 0.6f;
                    timerFillImage.color = Color.Lerp(Color.red, new Color(1f, 0.5f, 0.5f), pulse);
                    timerText.color = Color.red;
                }
                else if (gameTime <= warningThreshold)
                {
                    float pulse = Mathf.PingPong(Time.time * 2f, 0.3f) + 0.7f;
                    timerFillImage.color = Color.Lerp(Color.yellow, new Color(1f, 1f, 0.5f), pulse);
                    timerText.color = Color.yellow;
                }
                else
                {
                    timerFillImage.color = Color.green;
                    timerText.color = Color.white;
                }
            }
            if (gameTime <= 0)
            {
                bettingOpen = false;
                StartCoroutine(AutoPlaceBets());
            }
        }
    }
    IEnumerator AutoPlaceBets()
    {
        previousBets = new Dictionary<int, int>(bets);
        yield return StartCoroutine(SendBetsToApi());
        yield return StartCoroutine(FetchResultAndShow());
    }
    IEnumerator SendBetsToApi()
    {
        string token = PlayerPrefs.GetString("AUTH_KEY", "");
        if (string.IsNullOrEmpty(token))
        {
            Debug.LogError("No AUTH_KEY, cannot send bet.");
            yield break;
        }

        string url = $"{baseUrl}/v1/ticket/add-spin2win-ticket?token={token}";

        Spin2WinBetRequest reqObj = new Spin2WinBetRequest();
        reqObj.game_result_id = currentGameResultId;
        reqObj.game_id = gameId;
        reqObj.play_point = 0;

        // reset all fields
        reqObj.zero = reqObj.one = reqObj.two = reqObj.three = reqObj.four =
        reqObj.five = reqObj.six = reqObj.seven = reqObj.eight = reqObj.nine = 0;

        // fill with bets
        foreach (var kvp in GetBets())
        {
            reqObj.play_point += kvp.Value; // running total
            switch (kvp.Key)
            {
                case 0: reqObj.zero = kvp.Value; break;
                case 1: reqObj.one = kvp.Value; break;
                case 2: reqObj.two = kvp.Value; break;
                case 3: reqObj.three = kvp.Value; break;
                case 4: reqObj.four = kvp.Value; break;
                case 5: reqObj.five = kvp.Value; break;
                case 6: reqObj.six = kvp.Value; break;
                case 7: reqObj.seven = kvp.Value; break;
                case 8: reqObj.eight = kvp.Value; break;
                case 9: reqObj.nine = kvp.Value; break;
            }
        }

        string json = JsonUtility.ToJson(reqObj);
        Debug.Log("Bet payload: " + json);

        UnityWebRequest uw = new UnityWebRequest(url, "POST");
        byte[] bodyRaw = System.Text.Encoding.UTF8.GetBytes(json);
        uw.uploadHandler = new UploadHandlerRaw(bodyRaw);
        uw.downloadHandler = new DownloadHandlerBuffer();
        uw.SetRequestHeader("Content-Type", "application/json");

        yield return uw.SendWebRequest();

        if (uw.result != UnityWebRequest.Result.Success)
        {
            Debug.LogError("Bet API failed: " + uw.error + " body: " + uw.downloadHandler.text);
        }
        else
        {
            Debug.Log("Bet API success: " + uw.downloadHandler.text);
            ParseTotalBetFromResponse(uw.downloadHandler.text);
        }
    }
    // New method to parse total from API response
    private void ParseTotalBetFromResponse(string apiResponse)
    {
        try
        {
            var response = JsonUtility.FromJson<TicketResponseWrapper>(apiResponse);
            if (response != null && response.status && response.data != null)
            {
                int serverTotalBet = response.data.play_point;
                Debug.Log($"Server confirms total bet: {serverTotalBet}");

                // Update your UI with the server value
                if (totalBetText != null)
                    totalBetText.text = " " + serverTotalBet;

                // Optional: Sync your local bets dictionary with server data
               // SyncLocalBetsWithServer(response.data);
            }
        }
        catch (System.Exception e)
        {
            Debug.LogError("Error parsing ticket response: " + e.Message);
        }
    }
    private IEnumerator FetchWalletBalance()
    {
        currentWalletBalance = 1000;
        UpdateWalletDisplay();
        Debug.Log(" Wallet balance (HARDCODED): ${currentWalletBalance}");
        /* string token = PlayerPrefs.GetString("AUTH_KEY", "");
         if (string.IsNullOrEmpty(token))
         {
             Debug.LogError("No AUTH_KEY found. Cannot fetch wallet balance.");
             yield break;
         }

         string url = $"{baseUrl}/v1/users/wallet-balance?token={token}";
         UnityWebRequest req = UnityWebRequest.Get(url);
         yield return req.SendWebRequest();

         if (req.result != UnityWebRequest.Result.Success)
         {
             Debug.LogError("Fetch wallet balance failed: " + req.error);
         }
         else
         {
             try
             {
                 string jsonResponse = req.downloadHandler.text;
                 Debug.Log("Wallet balance response: " + jsonResponse);

                 var walletData = JsonUtility.FromJson<WalletBalanceWrapper>(jsonResponse);
                 if (walletData != null && walletData.status && walletData.data != null)
                 {
                     currentWalletBalance = walletData.data.wallet_balance;
                     UpdateWalletDisplay();
                     Debug.Log($"Wallet balance updated: ${currentWalletBalance}");
                 }
                 else
                 {
                     Debug.LogError("Failed to parse wallet balance data");
                 }
             }
             catch (System.Exception e)
             {
                 Debug.LogError("Error parsing wallet balance: " + e.Message);
             }
         }*/
        yield return null;
    }
    private void UpdateWalletDisplay()
    {
        if (walletBalanceText != null)
            walletBalanceText.text = $" {currentWalletBalance}";
    }

    // Fixed method - takes string parameter
    private void CalculateAndDisplayWinnings(string resultString)
    {
        int parsedResultNumber = ParseResultToNumber(resultString);
        winningNum = parsedResultNumber;
        totalWinnings = 0;

        if (parsedResultNumber == -1)
        {
            Debug.LogError($"Could not parse result: {resultString}");
            if (statusText != null)
                statusText.text = $"Error: Invalid result '{resultString}'";
            return;
        }

        // Check if player bet on the winning number
        if (bets.ContainsKey(parsedResultNumber) && bets[parsedResultNumber] > 0)
        {
            // Standard 9:1 payout for single number
            totalWinnings = bets[parsedResultNumber] * 9;

            // Update wallet balance locally
            currentWalletBalance += totalWinnings;
            UpdateWalletDisplay();
        }
        else
        {
            Debug.Log($"No winning bet. Result was {parsedResultNumber}");
        }

        DisplayWinningResults(parsedResultNumber, totalWinnings, resultString);
    }

    private int ParseResultToNumber(string result)
    {
        if (string.IsNullOrEmpty(result))
            return -1;

        // First try to parse as direct number
        if (int.TryParse(result, out int number))
        {
            return number;
        }

        // If that fails, try to parse text numbers
        result = result.Trim().ToLower();

        switch (result)
        {
            case "zero": return 0;
            case "one": return 1;
            case "two": return 2;
            case "three": return 3;
            case "four": return 4;
            case "five": return 5;
            case "six": return 6;
            case "seven": return 7;
            case "eight": return 8;
            case "nine": return 9;
            default: return -1;
        }
    }

    // Add this method to display winning results
    private void DisplayWinningResults(int resultNumber, int winnings, string originalResult)
    {
        if (winningNumberText != null)
        {
            if (resultNumber != -1)
                winningNumberText.text = $" {resultNumber} ";
            else
                winningNumberText.text = $" ";
        }

        if (winningAmountText != null)
        {
            if (winnings > 0)
            {
                winningAmountText.text = $"{winnings}";
                winningAmountText.color = Color.white; // Green for wins
            }
            else
            {
                winningAmountText.text = " ";
                winningAmountText.color = Color.white; // White for no win
            }
        }

        // Update status text
        if (statusText != null)
        {
            if (winnings > 0)
                statusText.text = $"Congratulations! You won {winnings}";
            else if (resultNumber != -1)
                statusText.text = $" Better luck next time!";
            else
                statusText.text = $" Better luck next time!";
        }

        // Update wallet on server (if player won)
        if (winnings > 0)
        {
            StartCoroutine(UpdateServerWalletBalance());
        }
    }
    private IEnumerator UpdateServerWalletBalance()
    {
        string token = PlayerPrefs.GetString("AUTH_KEY", "");
        if (string.IsNullOrEmpty(token))
        {
            Debug.LogError("No AUTH_KEY found. Cannot update server wallet.");
            yield break;
        }

        // Fetch updated balance to sync with server
        yield return StartCoroutine(FetchWalletBalance());

        Debug.Log($"Wallet sync complete. Current balance: ${currentWalletBalance}");
    }

    IEnumerator FetchResultAndShow()
    {
        string token = PlayerPrefs.GetString("AUTH_KEY", "");
        string url = $"{baseUrl}/v1/result/fetch-game-result-data?token={token}&game_result_id={currentGameResultId}";

        UnityWebRequest req = UnityWebRequest.Get(url);
        yield return req.SendWebRequest();

        if (req.result != UnityWebRequest.Result.Success)
        {
            Debug.LogError("Fetch result failed: " + req.error);
            if (statusText != null)
                statusText.text = "Error fetching results";
        }
        else
        {
            string raw = req.downloadHandler.text;
            Debug.Log("Fetch result raw: " + raw);

            //DebugAPIResponseStructure(raw);

            try
            {
                var wrap = JsonUtility.FromJson<GameResultDataWrapper>(raw);
                if (wrap != null && wrap.data != null)
                {
                    string result = wrap.data.result;
                    if (wrap != null && wrap.data != null)
                    {
                        if (!string.IsNullOrEmpty(result))
                        {
                            if (statusText != null)
                                statusText.text = "Spinning...";

                            int resultNumber = ParseResultToNumber(result);
                            if (resultNumber != -1)
                            {
                                // Calculate winnings first
                                CalculateWinnings(resultNumber);

                                // Start wheel spin if available
                                if (wheelSpinner != null)
                                {
                                    wheelSpinner.onSpinComplete.AddListener(OnWheelComplete);
                                    wheelSpinner.SpinToNumber(resultNumber);
                                    yield break; // Important: exit here and wait for wheel callback
                                }
                                else
                                {
                                    // No wheel - show results immediately
                                    ShowResults(resultNumber);
                                }
                            }
                        }
                    
                }
                    else
                    {
                        Debug.LogError("Empty result received");
                        if (statusText != null)
                            statusText.text = "No result data";
                    }
                }
                else
                {
                    Debug.LogError("Invalid result wrapper or data");
                    if (statusText != null)
                        statusText.text = "Invalid result format";
                }
            }
            catch (System.Exception e)
            {
                Debug.LogError("Failed to parse result JSON: " + e.Message);
                if (statusText != null)
                    statusText.text = "Error parsing result";
            }
        }
        yield return new WaitForSeconds(20f);

        if (endRoundPanel != null) endRoundPanel.SetActive(true);
    }
    private void CalculateWinnings(int resultNumber)
    {
        totalWinnings = 0;

        if (bets.ContainsKey(resultNumber) && bets[resultNumber] > 0)
        {
            totalWinnings = bets[resultNumber] * 9;
           // currentWalletBalance += totalWinnings;
            //UpdateWalletDisplay();

            
        }
    }

    public void DoubleBets()
    {
        int currentTotal = GetTotalBetAmount();
        int doubledTotal = currentTotal * 2;

        // Check if player has sufficient balance
        int additionalAmount = doubledTotal - currentTotal;
        if (doubledTotal > currentWalletBalance)
        {
            if (statusText != null)
                statusText.text = "Insufficient balance to double!";
            return;
        }
        //currentWalletBalance -= additionalAmount;
        // Double each bet
        foreach (var number in new List<int>(bets.Keys))
        {
            if (bets[number] > 0)
            {
                bets[number] *= 2;
            }
        }

        UpdateTotalUI();
       // UpdateWalletDisplay();
        RefreshChipVisuals();

        if (statusText != null)
            statusText.text = "Bets doubled!";
    }
    public void ClearAllBets()
    {
        if (GetTotalBetAmount() > 0)
        {
            previousBets = new Dictionary<int, int>(bets);
        }
        //int totalReturned = GetTotalBetAmount();
        //currentWalletBalance += totalReturned; 

        bets.Clear();
        UpdateTotalUI();
        //UpdateWalletDisplay();
        // Clear visual chips
        foreach (var card in cards)
        {
            if (card != null && card.chipContainer != null)
            {
                foreach (Transform child in card.chipContainer)
                {
                    Destroy(child.gameObject);
                }
            }
        }

        if (statusText != null)
            statusText.text = "All bets cleared!";
    }
    private void RefreshChipVisuals()
    {
        foreach (var card in cards)
        {
            if (card != null && card.chipContainer != null)
            {
                foreach (Transform child in card.chipContainer)
                {
                    Destroy(child.gameObject);
                }
            }
        }

        foreach (var kvp in bets)
        {
            if (kvp.Value > 0)
            {
                var card = cards.Find(c => c.cardNumber == kvp.Key);
                if (card != null && card.chipContainer != null)
                {
                    GameObject prefab = GetChipPrefab(GetChipValueForAmount(kvp.Value));
                    if (prefab != null)
                    {
                        Instantiate(prefab, card.chipContainer);
                    }
                }
            }
        }
    }

    private int GetChipValueForAmount(int amount)
    {
        int[] chipValues = { 500, 100, 50, 10, 5 };
        foreach (int chip in chipValues)
        {
            if (amount >= chip)
                return chip;
        }
        return 5;
    }
    private void OnWheelComplete(int winningNumber)
    {
        wheelSpinner.onSpinComplete.RemoveListener(OnWheelComplete);
        ShowResults(winningNumber);
        ShowEndPanel();
    }

    private void ShowResults(int resultNumber)
    {
        if (winningNumberText != null)
            winningNumberText.text = $" {resultNumber}";

        if (winningAmountText != null)
        {
            winningAmountText.text = totalWinnings > 0 ? $" {totalWinnings}" : "No Win";
            winningAmountText.color = totalWinnings > 0 ? Color.white : Color.white;
        }
        if (totalWinnings > 0)
        {
            currentWalletBalance += totalWinnings;
            UpdateWalletDisplay();
        }

        if (statusText != null)
            statusText.text = totalWinnings > 0 ? $"{totalWinnings}!" : "Better luck next time!";

        if (glowEffect != null)
        {
            glowEffect.SetActive(totalWinnings > 0);
        }
    }

    private void ShowEndPanel()
    {
        StartCoroutine(ShowPanelAfterDelay());
    }

    private IEnumerator ShowPanelAfterDelay()
    {
        yield return new WaitForSeconds(20f); // Wait 20 seconds
        if (endRoundPanel != null)
            endRoundPanel.SetActive(true);

        if (glowEffect != null)
            glowEffect.SetActive(false);
    }
    
    [System.Serializable]
    public class SimpleResponseWrapper
    {
        public bool status;
        public string message;
        public object data; // Use object to avoid strict typing initially
    }
    // Wrapper classes - FIXED DUPLICATES
    [System.Serializable]
    public class LatestGameIdWrapper { public bool status; public LatestGameIdData data; }
    [System.Serializable]
    public class LatestGameIdData { public int id; }

    [System.Serializable]
    public class GameTimeWrapper { public bool status; public GameTimeData data; }
    [System.Serializable]
    public class GameTimeData { public int game_time; }

    [System.Serializable]
    public class GameResultDataWrapper
    {
        public bool status;
        public string message;
        public GameResultInfoData data;
    }

    [System.Serializable]
    public class GameResultInfoData
    {
        public string result;
        public int id;
        public int game_id;
        public string game_time;
        public string status;
    }

    [System.Serializable]
    public class WalletBalanceWrapper
    {
        public bool status;
        public string message;
        public WalletBalanceData data;
    }

    [System.Serializable]
    public class WalletBalanceData
    {
        public int wallet_balance;
    }
    [System.Serializable]
    public class TicketResponseWrapper
    {
        public bool status;
        public string message;
        public TicketResponseData data;
    }

    [System.Serializable]
    public class TicketResponseData
    {
        public int play_point;
        public int id;
        public int game_id;
        public int game_result_id;
        public int user_id;
        public GameSlotObj game_slot_obj;
        // Add other fields as needed
    }

    public class GameSlotObj
    {
        public int zero;
        public int one;
        public int two;
        public int three;
        public int four;
        public int five;
        public int six;
        public int seven;
        public int eight;
        public int nine;
    }
}