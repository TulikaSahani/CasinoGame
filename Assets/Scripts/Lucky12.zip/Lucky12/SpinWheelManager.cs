using UnityEngine;
using System;
using System.Collections;

public class SpinWheelManager : MonoBehaviour
{
    public RectTransform wheelOuter;
    public RectTransform wheelInner;
    public float defaultDuration = 3f;
    private bool isSpinning = false;

    // Start spinning to a specific index (0..11). onComplete runs after spin finished.
    public void StartSpinToIndex(int index, float duration, Action onComplete)
    {
        if (!isSpinning) StartCoroutine(SpinRoutine(index, duration, onComplete));
    }

    private IEnumerator SpinRoutine(int index, float duration, Action onComplete)
    {
        if (wheelOuter == null || wheelInner == null)
        {
            onComplete?.Invoke();
            yield break;
        }

        isSpinning = true;

        int slotCount = 12;
        float anglePer = 360f / slotCount;
        float targetAngle = index * anglePer;

        float startOuter = wheelOuter.localEulerAngles.z;
        float finalOuter = startOuter + 360f * 6f + (targetAngle - (startOuter % 360f));
        float startInner = wheelInner.localEulerAngles.z;
        float finalInner = startInner + 360f * 6f + (targetAngle - (startInner % 360f));

        float t = 0f;
        while (t < duration)
        {
            t += Time.deltaTime;
            float u = Mathf.Clamp01(t / duration);
            // ease out cubic
            float ease = 1f - Mathf.Pow(1f - u, 3f);
            float aOuter = Mathf.LerpAngle(startOuter, finalOuter, ease);
            float aInner = Mathf.LerpAngle(startInner, finalInner, ease);
            wheelOuter.localEulerAngles = new Vector3(0f, 0f, aOuter);
            wheelInner.localEulerAngles = new Vector3(0f, 0f, aInner);
            yield return null;
        }

        wheelOuter.localEulerAngles = new Vector3(0f, 0f, finalOuter);
        wheelInner.localEulerAngles = new Vector3(0f, 0f, finalInner);

        isSpinning = false;
        onComplete?.Invoke();
    }
}
