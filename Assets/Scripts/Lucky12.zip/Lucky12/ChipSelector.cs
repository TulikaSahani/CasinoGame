using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class ChipSelector : MonoBehaviour
{
    public int chipValue;        // assign 5, 10, 50, 70, 500
    public TMP_Text chipText;    // assign TMP text inside the chip
    public Image chipImage;      // assign the Image component of THIS chip

    private Vector3 originalScale;
    private bool isSelected = false;

    void Start()
    {
        originalScale = transform.localScale;
        if (chipText != null)
            chipText.text = chipValue.ToString();
    }

    public void OnChipClicked()
    {
        if (isSelected)
        {
            Deselect();
            ChipManager.Instance.ClearSelection();
        }
        else
        {
            ChipManager.Instance.SelectChip(this);
        }
    }

    public void Select()
    {
        isSelected = true;
        transform.localScale = originalScale * 1.2f; // grow
        //transform.Rotate(Vector3.forward, 15f);      // spin
    }

    public void Deselect()
    {
        isSelected = false;
        transform.localScale = originalScale;
       // transform.rotation = Quaternion.identity;
    }

    public Sprite GetSprite()
    {
        return chipImage != null ? chipImage.sprite : null;
    }
}
