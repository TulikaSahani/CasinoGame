using UnityEngine;

public class ChipManager : MonoBehaviour
{
    public static ChipManager Instance;
    private ChipSelector currentChip;

    void Awake() { Instance = this; }

    public void SelectChip(ChipSelector chip)
    {
        if (currentChip != null) currentChip.Deselect();
        currentChip = chip;
        currentChip.Select();
    }

    public void ClearSelection()
    {
        if (currentChip != null) currentChip.Deselect();
        currentChip = null;
    }

    public int GetSelectedChipValue()
    {
        return currentChip != null ? currentChip.chipValue : 0;
    }

    public Sprite GetSelectedChipSprite()
    {
        return currentChip != null ? currentChip.GetSprite() : null;
    }
}
