﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using TMPro;
using UnityEngine.UI;

public class BetManager : MonoBehaviour
{
    public static BetManager Instance;

    [Header("API")]
    public string baseUrl = "https://casino-backend.realtimevillage.com/api";
    public int gameId = 2;
    public float fallbackGameTime = 30f;

    [Header("UI - Texts & Buttons")]
    public TMP_Text timerText;
    public TMP_Text statusText;
    public TMP_Text totalBetText;
    public Button placeBetButton;

    [Header("Chips & Interaction")]
    public List<Button> chipButtons = new List<Button>();

    [Header("Wheel (optional)")]
    public RectTransform wheelOuter;
    public RectTransform wheelInner;

    [Header("Timer thresholds (seconds)")]
    public float warningThreshold = 15f;
    public float lockThreshold = 10f;

    // internal
    [HideInInspector] public List<CardBetSpot> cardSpots = new List<CardBetSpot>();
    private float game_time = 0f;
    private bool bettingOpen = false;
    private bool spinning = false;
    private bool roundComplete = false;
    private int currentGameResultId = 0;
    private bool roundInitialized = false; // NEW: Track if round is properly initialized

    // wheel mapping 
    private readonly string[] cardCodes = new string[]
    {
        "JS","QS","KS",
        "JD","QD","KD",
        "JC","QC","KC",
        "JH","QH","KH"
    };
    private const int SLOT_COUNT = 12;
    private float anglePerSlot => 360f / SLOT_COUNT;

    void Awake()
    {
        Instance = this;
    }

    void Start()
    {
        // Start the first round - FIXED: Use proper initialization
        StartCoroutine(InitializeRound());
    }
    public void UpdateBetButtonState()
    {
        if (placeBetButton != null)
        {
            placeBetButton.interactable = bettingOpen && HasAnyBet() && !spinning;
        }
    }

    #region Registration / UI helpers

    // Clear all card bets
    public void OnClearClicked()
    {
        foreach (var c in cardSpots)
            c.ClearBet();
        UpdateTotalUI();
    }

    // Double all card bets 
    public void OnDoubleClicked()
    {
        foreach (var c in cardSpots)
            c.DoubleBet();
        UpdateTotalUI();
    }

    public void OnBetClicked()
    {
        if (!bettingOpen || spinning) return;

        int total = CalculateTotal();
        if (total <= 0)
        {
            if (statusText != null) statusText.text = "Place a bet first.";
            return;
        }

        // lock betting
        bettingOpen = false;
        SetAllInteractive(false);
        if (statusText != null) statusText.text = "Bet locked. Resolving...";

        StartCoroutine(PlaceBetsThenResolve());
    }

    public void RegisterCard(CardBetSpot card)
    {
        if (!cardSpots.Contains(card)) cardSpots.Add(card);
    }

    public void OnWheelSpinComplete()
    {
        Debug.Log("Wheel spin complete → fetching result...");
        StartCoroutine(FetchResultAndSpin());
    }

    public int CalculateTotal()
    {
        int t = 0;
        foreach (var c in cardSpots) t += c.GetTotalBet();
        return t;
    }

    public void UpdateTotalUI()
    {
        if (totalBetText != null) totalBetText.text = "Total: " + CalculateTotal();
        UpdateBetButtonState();
    }

    bool HasAnyBet() => CalculateTotal() > 0;

    void SetAllInteractive(bool on)
    {
        // cards
        foreach (var c in cardSpots)
        {
            var btn = c.GetComponent<Button>();
            if (btn != null) btn.interactable = on;
        }

        // chips
        foreach (var b in chipButtons)
            if (b != null) b.interactable = on;

        // place button is handled separately
        if (placeBetButton != null) placeBetButton.interactable = bettingOpen;
        UpdateBetButtonState();
    }

    // Apply chip to ALL cards
    public void ApplyChipToAll()
    {
        foreach (var spot in cardSpots)
        {
            spot.AddChipFromManager();
        }
        
        UpdateBetButtonState();
    }

    public void ApplyChipToRank(char rank)
    {
        foreach (var spot in cardSpots)
        {
            if (!string.IsNullOrEmpty(spot.CardCode) && spot.CardCode.StartsWith(rank.ToString()))
            {
                spot.AddChipFromManager();
            }
        }
       
        UpdateBetButtonState();
    }

    #endregion

    #region Round setup (API calls)

    // NEW: Proper round initialization method
    IEnumerator InitializeRound()
    {
        roundComplete = false;
        roundInitialized = false;

        // disable interaction while fetching
        SetAllInteractive(false);
        if (statusText != null) statusText.text = "Initializing round...";
        spinning = false;

        string token = PlayerPrefs.GetString("AUTH_KEY", "");
        if (string.IsNullOrEmpty(token))
        {
            Debug.LogError("No AUTH_KEY found in PlayerPrefs. Login first.");
            if (statusText != null) statusText.text = "Not logged in.";
            yield break;
        }

        // 1) get latest-game-result-id
        string urlId = $"{baseUrl}/v1/result/latest-game-result-id?token={token}&game_id={gameId}";
        UnityWebRequest reqId = UnityWebRequest.Get(urlId);
        yield return reqId.SendWebRequest();

        if (reqId.result != UnityWebRequest.Result.Success)
        {
            Debug.LogError("Error fetching latest-game-result-id: " + reqId.error);
            if (statusText != null) statusText.text = "Failed to get round id.";

            // Fallback: Use default timer and continue
            game_time = fallbackGameTime;
            bettingOpen = true;
            SetAllInteractive(true);
            roundInitialized = true;
            if (statusText != null) statusText.text = "Betting open";
            yield break;
        }

        Debug.Log("latest-game-result-id raw: " + reqId.downloadHandler.text);
        try
        {
            var idWrap = JsonUtility.FromJson<LatestGameIdWrapper>(reqId.downloadHandler.text);
            if (idWrap != null && idWrap.data != null)
            {
                currentGameResultId = idWrap.data.id;
                Debug.Log($"Current game result ID: {currentGameResultId}");
            }
            else
            {
                Debug.LogWarning("Could not parse latest-game-result-id; using previous id if available.");
            }
        }
        catch (Exception e)
        {
            Debug.LogWarning("Exception parsing latest-game-result-id: " + e.Message);
        }

        // Save result id to PlayerPrefs so Bet API can use it
        PlayerPrefs.SetInt("CurrentGameResultId", currentGameResultId);
        PlayerPrefs.Save();

        // 2) get latest-game-time
        string urlTime = $"{baseUrl}/v1/result/latest-game-time?token={token}&game_id={gameId}&game_result_id={currentGameResultId}";
        UnityWebRequest reqTime = UnityWebRequest.Get(urlTime);
        yield return reqTime.SendWebRequest();

        if (reqTime.result != UnityWebRequest.Result.Success)
        {
            Debug.LogError("Error fetching latest-game-time: " + reqTime.error);
            if (statusText != null) statusText.text = "Failed to get timer. Using default.";

            game_time = fallbackGameTime;
        }
        else
        {
            string raw = reqTime.downloadHandler.text;
            Debug.Log("latest-game-time raw: " + raw);

            try
            {
                var tw = JsonUtility.FromJson<GameTimeWrapper>(raw);
                if (tw != null && tw.data != null && tw.data.game_time > 0)
                {
                    game_time = tw.data.game_time;
                    Debug.Log($"Using API game_time: {game_time}");
                }
                else
                {
                    game_time = fallbackGameTime;
                    Debug.LogWarning("API returned 0 or missing game_time; using fallback: " + fallbackGameTime);
                }
            }
            catch (Exception e)
            {
                game_time = fallbackGameTime;
                Debug.LogWarning("Exception parsing game_time; using fallback: " + e.Message);
            }
        }

        // IMPORTANT: Only start betting if we have sufficient time
        bettingOpen = (game_time > lockThreshold);
        SetAllInteractive(bettingOpen);
        if (placeBetButton != null) placeBetButton.interactable = bettingOpen && HasAnyBet();
        UpdateBetButtonState();

        if (statusText != null)
            statusText.text = bettingOpen ? "Betting open" : "Betting closed";

        UpdateTimerUI();
        roundInitialized = true;
        Debug.Log("Round initialized successfully. Timer: " + game_time);
    }

    IEnumerator PlaceBetsThenResolve()
    {
        bool ok = false;
        yield return StartCoroutine(SendBetsToApi(success => ok = success));

        if (!ok)
        {
            if (statusText != null) statusText.text = "Bet failed.";
            // Re-enable betting if failed
            bettingOpen = true;
            SetAllInteractive(true);
            yield break;
        }

        // After sending bets, wait for timer to complete or fetch result immediately
        if (game_time > 0)
        {
            if (statusText != null) statusText.text = "Bet placed. Waiting for round end...";
            // Let the timer countdown naturally
        }
        else
        {
            // If timer already ended, fetch result immediately
            yield return StartCoroutine(FetchResultAndSpin());
        }
    }

    IEnumerator SendBetsToApi(System.Action<bool> onComplete)
    {
        string token = PlayerPrefs.GetString("AUTH_KEY", "");
        if (string.IsNullOrEmpty(token))
        {
            Debug.LogError("No AUTH_KEY, cannot send bet.");
            onComplete?.Invoke(false);
            yield break;
        }

        string url = $"{baseUrl}/v1/ticket/add-lucky12-ticket?token={token}";

        // Build request object
        Lucky12BetRequest reqObj = new Lucky12BetRequest();
        reqObj.game_result_id = currentGameResultId;
        reqObj.game_id = gameId;
        reqObj.play_point = CalculateTotal();

        // reset all to 0
        reqObj.JS = reqObj.QS = reqObj.KS =
        reqObj.JD = reqObj.QD = reqObj.KD =
        reqObj.JC = reqObj.QC = reqObj.KC =
        reqObj.JH = reqObj.QH = reqObj.KH = 0;

        // assign bets from cardSpots
        foreach (var c in cardSpots)
        {
            if (c == null) continue;
            int bet = c.GetTotalBet();
            if (bet > 0 && !string.IsNullOrEmpty(c.CardCode))
            {
                switch (c.CardCode)
                {
                    case "JS": reqObj.JS = bet; break;
                    case "QS": reqObj.QS = bet; break;
                    case "KS": reqObj.KS = bet; break;
                    case "JD": reqObj.JD = bet; break;
                    case "QD": reqObj.QD = bet; break;
                    case "KD": reqObj.KD = bet; break;
                    case "JC": reqObj.JC = bet; break;
                    case "QC": reqObj.QC = bet; break;
                    case "KC": reqObj.KC = bet; break;
                    case "JH": reqObj.JH = bet; break;
                    case "QH": reqObj.QH = bet; break;
                    case "KH": reqObj.KH = bet; break;
                }
            }
        }

        string json = JsonUtility.ToJson(reqObj);
        Debug.Log("SendBet payload: " + json);

        UnityWebRequest uw = new UnityWebRequest(url, "POST");
        byte[] bodyRaw = System.Text.Encoding.UTF8.GetBytes(json);
        uw.uploadHandler = new UploadHandlerRaw(bodyRaw);
        uw.downloadHandler = new DownloadHandlerBuffer();
        uw.SetRequestHeader("Content-Type", "application/json");

        yield return uw.SendWebRequest();

        if (uw.result != UnityWebRequest.Result.Success)
        {
            Debug.LogError("Bet API failed: " + uw.error + " body: " + uw.downloadHandler.text);
            onComplete?.Invoke(false);
        }
        else
        {
            Debug.Log("Bet API success: " + uw.downloadHandler.text);
            onComplete?.Invoke(true);
        }
    }

    [Serializable]
    public class Lucky12BetRequest
    {
        public int game_result_id;
        public int game_id;
        public int play_point;

        public int JS, QS, KS;
        public int JD, QD, KD;
        public int JC, QC, KC;
        public int JH, QH, KH;
    }

    void UpdateTimerUI()
    {
        if (timerText == null) return;

        int minutes = Mathf.FloorToInt(game_time / 60f);
        int seconds = Mathf.FloorToInt(game_time % 60f);
        timerText.text = string.Format("{0:00}:{1:00}", minutes, seconds);

        if (game_time <= lockThreshold)
            timerText.color = Color.red;
        else if (game_time <= warningThreshold)
            timerText.color = Color.yellow;
        else
            timerText.color = Color.white;
    }

    #endregion

    #region Update timer / lock logic
    void Update()
    {
        // Only update if round is properly initialized
        if (!roundInitialized || spinning || roundComplete) return;

        // update countdown if time left
        if (game_time > 0f)
        {
            game_time -= Time.deltaTime;
            if (game_time < 0f) game_time = 0f;

            UpdateTimerUI();

            // lock betting when crossing lockThreshold
            if (bettingOpen && game_time <= lockThreshold)
            {
                bettingOpen = false;
                SetAllInteractive(false);
                if (placeBetButton != null) placeBetButton.interactable = false;
                if (statusText != null) statusText.text = "Betting closed";
            }
        }

        // Only trigger result when timer reaches 0 and we're not already processing
        if (game_time <= 0f && !spinning && !roundComplete)
        {
            roundComplete = true;
            if (statusText != null) statusText.text = "Time up! Resolving...";
            StartCoroutine(FetchResultAndSpin());
        }
    }
    #endregion

    #region Fetch result & spin
    IEnumerator FetchResultAndSpin()
    {
        if (spinning) yield break; // Prevent multiple simultaneous spins

        spinning = true;
        roundComplete = true;

        if (statusText != null) statusText.text = "Fetching result...";

        string token = PlayerPrefs.GetString("AUTH_KEY", "");
        string url = $"{baseUrl}/v1/result/fetch-game-result-data?token={token}&game_result_id={currentGameResultId}";
        UnityWebRequest req = UnityWebRequest.Get(url);
        yield return req.SendWebRequest();

        string resultCode = null;

        if (req.result == UnityWebRequest.Result.Success)
        {
            string raw = req.downloadHandler.text;
            Debug.Log("Fetch result raw: " + raw);
            try
            {
                var wrap = JsonUtility.FromJson<GameResultWrapper>(raw);
                if (wrap != null && wrap.data != null && !string.IsNullOrEmpty(wrap.data.result))
                {
                    resultCode = wrap.data.result.Trim();
                }
            }
            catch (Exception e)
            {
                Debug.LogWarning("Exception parsing fetch-game-result-data: " + e.Message);
            }
        }
        else
        {
            Debug.LogError("Fetch result failed: " + req.error);
        }

        // fallback if no result
        int idx = -1;
        if (!string.IsNullOrEmpty(resultCode))
        {
            idx = Array.IndexOf(cardCodes, resultCode);
            if (idx < 0)
            {
                Debug.LogWarning("Result code not found in mapping: " + resultCode);
                idx = UnityEngine.Random.Range(0, SLOT_COUNT);
            }
        }
        else
        {
            Debug.LogWarning("Result not available, using random fallback.");
            idx = UnityEngine.Random.Range(0, SLOT_COUNT);
        }

        // Spin the wheel
        yield return StartCoroutine(SpinWheelsToIndex(idx, 3.0f));

        // Show result
        if (statusText != null)
            statusText.text = "Winner: " + (resultCode ?? cardCodes[idx]);

        // Refresh wallet
        yield return StartCoroutine(RefreshWalletCoroutine());

        // Wait before starting new round
        yield return new WaitForSeconds(2f);

        // Start new round
        spinning = false;
        StartCoroutine(InitializeRound());
    }

    IEnumerator SpinWheelsToIndex(int index, float duration)
    {
        if (wheelOuter == null || wheelInner == null)
        {
            Debug.LogWarning("Wheel transforms not assigned; skipping spin animation.");
            yield break;
        }

        float startOuter = wheelOuter.localEulerAngles.z;
        float startInner = wheelInner.localEulerAngles.z;

        // compute target (we want final %360 to equal index*anglePerSlot)
        float targetAngle = index * anglePerSlot;

        int spins = 6;
        float finalOuter = startOuter + spins * 360f + (targetAngle - (startOuter % 360f));
        float finalInner = startInner + spins * 360f + (targetAngle - (startInner % 360f));

        float t = 0f;
        while (t < duration)
        {
            t += Time.deltaTime;
            float u = Mathf.Clamp01(t / duration);
            float ease = 1f - Mathf.Pow(1f - u, 3f);
            float angleOuter = Mathf.LerpAngle(startOuter, finalOuter, ease);
            float angleInner = Mathf.LerpAngle(startInner, finalInner, ease);
            wheelOuter.localEulerAngles = new Vector3(0f, 0f, angleOuter);
            wheelInner.localEulerAngles = new Vector3(0f, 0f, angleInner);
            yield return null;
        }

        wheelOuter.localEulerAngles = new Vector3(0f, 0f, finalOuter);
        wheelInner.localEulerAngles = new Vector3(0f, 0f, finalInner);
    }
    #endregion

    #region Wallet refresh
    IEnumerator RefreshWalletCoroutine()
    {
        string token = PlayerPrefs.GetString("AUTH_KEY", "");
        if (string.IsNullOrEmpty(token)) yield break;

        string url = $"{baseUrl}/v1/users/wallet-balance?token={token}";
        UnityWebRequest req = UnityWebRequest.Get(url);
        yield return req.SendWebRequest();
        if (req.result == UnityWebRequest.Result.Success)
        {
            Debug.Log("Wallet response: " + req.downloadHandler.text);
            try
            {
                WalletWrapper w = JsonUtility.FromJson<WalletWrapper>(req.downloadHandler.text);
                if (w != null && w.data != null)
                {
                    // Update wallet UI here if needed
                }
            }
            catch (Exception e)
            {
                Debug.LogWarning("Failed to parse wallet response: " + e.Message);
            }
        }
    }
    #endregion

    #region JSON wrappers
    [Serializable] public class LatestGameIdWrapper { public bool status; public string message; public LatestGameIdData data; }
    [Serializable] public class LatestGameIdData { public int id; }

    [Serializable] public class GameTimeWrapper { public bool status; public string message; public GameTimeData data; }
    [Serializable] public class GameTimeData { public int game_time; }

    [Serializable] public class GameResultWrapper { public bool status; public string message; public GameResultData data; }
    [Serializable] public class GameResultData { public string result; }

    [Serializable] public class WalletWrapper { public bool status; public WalletData data; }
    [Serializable] public class WalletData { public int wallet_balance; }
    #endregion
}